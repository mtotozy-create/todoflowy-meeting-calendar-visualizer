# @todoflowy/plugin-runtime

Owns host-independent opaque-origin frame creation, immutable CSP/SRI bootstrap assets, runtime/view lifecycle, single-entry ESM transfer, request routing, limits, and deterministic disposal.

Public host API:

- `createPluginInstance(options)` returns `start()`, `emit()`, `dispose()`, and readonly `state`.
- `PluginHostAdapter` dynamically reads grants and invokes already validated requests with trusted instance identity.
- Bootstrap assets are exported with stable paths, SHA-256 metadata, CSP, and SRI.

The package never imports TodoFlowy application code or owns account IDs, tokens, Repository behavior, commercial gates, Tauri commands, or React adapters. It remains private `0.0.0`; Windows WebView2, Linux WebKitGTK, and independent security review are required before production release.
