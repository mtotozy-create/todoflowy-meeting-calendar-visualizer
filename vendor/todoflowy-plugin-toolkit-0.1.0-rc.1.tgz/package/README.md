# @todoflowy/plugin-toolkit

Local package tooling for TodoFlowy plugin authors. Plugin runtime and view entries must already be built as self-contained ESM files; Toolkit does not bundle or transpile source code.

```bash
todoflowy-plugin validate plugin.zip --todoflowy-version 0.4.1 --plugin-api-range '^1.0.0'
todoflowy-plugin pack ./plugin --out plugin.zip --resource assets --todoflowy-version 0.4.1 --plugin-api-range '^1.0.0'
todoflowy-plugin hash plugin.zip
todoflowy-plugin inspect plugin.zip --todoflowy-version 0.4.1 --plugin-api-range '^1.0.0'
todoflowy-plugin dev ./plugin --resource assets --todoflowy-version 0.4.1 --plugin-api-range '^1.0.0'
```

`pack` includes `manifest.json`, the runtime entry, visual extension entries, and explicit repeatable `--resource` files or directories. Paths are confined to the plugin root; links and non-regular files are rejected. Sorted paths, ZIP epoch timestamps, Unix `0644` metadata, and fixed compression produce identical bytes for identical normalized paths and file contents. The completed archive is validated in memory before an atomic output rename.

`validate` and `inspect` apply the package Validator and require an explicit target TodoFlowy version and Plugin API range. `hash` computes a streaming SHA-256 for any regular file. Errors use stable codes and do not print absolute paths or raw system exceptions.

`dev` validates the same in-memory package snapshot before binding a random `127.0.0.1` port. Its fixed host uses the production Runtime for one runtime iframe, each visual extension iframe, toolbar commands, and a deterministic in-memory adapter for all 14 standard requests, including a non-I/O network response. It exposes only fixed host/bootstrap/data routes and contained Runtime, Contracts, and TypeBox ESM files. It does not open external network connections, read the source tree after startup, persist data, watch files, or provide authentication, TodoFlowy Repository, React, or Tauri behavior. Stop it with `SIGINT` or `SIGTERM`.
