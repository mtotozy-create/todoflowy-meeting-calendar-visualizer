# @todoflowy/plugin-contracts

Owns versioned runtime schemas and matching TypeScript types for Manifest, protocol envelopes, capabilities, public DTOs, registry entries, and stable errors. It must not depend on any other TodoFlowy package.
