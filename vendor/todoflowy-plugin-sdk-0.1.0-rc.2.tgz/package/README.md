# @todoflowy/plugin-sdk

Typed developer API for TodoFlowy runtime and view plugins. It depends only on public plugin contracts and TypeBox validation, and communicates exclusively with the parent Runtime message channel.

Runtime entry:

```ts
import { defineRuntime, plugin } from "@todoflowy/plugin-sdk";

export const { activate, deactivate } = defineRuntime({
  async activate() {
    const todos = await plugin.todos.list({ view: "today" });
    console.log(todos.items.length);
  },
  deactivate() {},
});
```

View entry:

```ts
import { defineView, plugin } from "@todoflowy/plugin-sdk";

export const { mount } = defineView({
  async mount(root) {
    root.dataset.theme = await plugin.theme.get();
    return () => root.replaceChildren();
  },
});
```

The frozen `plugin` singleton exposes `todos`, `meetings`, `storage`, `ui`, `context`, `theme`, and typed standard-event subscriptions. Failed requests throw `PluginApiError`; `plugin.events.on()` returns an idempotent unsubscribe function.

Meeting reads use an explicit scope so a plugin never probes personal and team namespaces to discover where an ID exists:

```ts
const page = await plugin.meetings.list({ scope: "personal", limit: 20 });
const meeting = await plugin.meetings.get(page.items[0].id, "personal");
const transcript = await plugin.meetings.getContent(meeting.id, {
  scope: "personal",
  section: "transcript",
  limit: 50,
});
```

Metadata requires `meetings:read` for personal scope or `meetings:team:read` for team scope. Content also requires `meetings:content:read`. Transcript and resolution pages must be followed with `nextCursor`; no meeting playback, download, export, mutation, or event API is exposed.

See the [meeting read guide](../../docs/plugin-development/meeting-read.md) for Manifest capability combinations, complete pagination examples, stable error handling, privacy boundaries, and current release availability. The `0.1.0-rc.1` private candidate contains these types and methods; a host must upgrade to a compatible client before use.

Request methods are available inside `activate()` or `mount()`, after the SDK has validated the lifecycle session. Module-top-level requests, including top-level await, fail immediately with `INSTANCE_DISPOSED`. Event listeners may be registered at module scope because subscription does not send a request.

The package does not expose a generic request API, transport, nonce, account identity, capability grant, host token, network, filesystem, Runtime, React, or Tauri integration.
