# @todoflowy/plugin-package-validator

Owns pure validation for manifests, compatibility ranges, normalized package paths, zip resource limits, registry entries, and integrity metadata. It does not read arbitrary filesystem paths or install packages.

`verifySha256()` and `validatePackage()` are asynchronous because integrity checks use native Web Crypto in Node and browser WebViews. ZIP, Manifest, SemVer, and registry schema helpers remain synchronous.
